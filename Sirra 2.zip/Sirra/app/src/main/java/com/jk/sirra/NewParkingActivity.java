package com.jk.sirra;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Calendar;

public class NewParkingActivity extends AppCompatActivity implements view.OnClickListener,AdapterView.OnItemSelectedListener{
     EditText edtCarPlate;
      TextView txtAmount,txtDateTime;
      Spinner spnLot,spnSpot,spnPayment,spnCarCompany;
      Button btnAddParking;
      RadioButton rdoOne,rdoTwo,rdoThree,rdoFour;

      int parkingRate[] ={0,20,30,100};
      String[] lots ={"A","B","C","D","E"};
      String [] spots ={"1","2","3","4","5","6"};
      String[]paymentMethods ={"Credit Card","Debit Card","Master Card","American Express"};
      String[]companyNames ={"BMW","Audi","Jaguar","Lexus","Mercedes"};
      int[]logos ={R.drawable.img_bmw,R.drawable.img_audi,R.drawable.img_jaguar,R.drawable.img_lexus,R.drawable.img_mercedes};

      String[] selectedLot,selectedSpot,slectedPayment,selectedCompany;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_parking);

        edtCarPlate = findViewById(R.id.edtCarPlate);
        txtAmount = findViewById(R.id.txtAmount);
        txtAmount.setText("$"+parkingRate[0]);

        txtDateTime = findViewById(R.id.txtDateTime);
        txtDateTime.setText(Calendar.getInstance().getTime().toString());
        btnAddParking = findViewById(R.id.btnAddParking);
        btnAddParking.setOnClickListener(this);

        rdoOne = findViewById(R.id.rdoOne);
        rdoOne.setOnClickListener(this);

        rdoTwo = findViewById(R.id.rdoTwo);
        rdoTwo.setOnClickListener(this);

        rdoThree = findViewById(R.id.rdoThree);
        rdoThree.setOnClickListener(this);

        rdoFour = findViewById(R.id.rdoFour);
        rdoFour.setOnClickListener(this);

        spnLot = findViewById(R.id.spnLot);
        ArrayAdapter lotadapter = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,lots);
        spnLot.setAdapter(lotadapter);
        spnLot.setOnItemSelectedListener(this);

        spnSpot = findViewById(R.id.spnSpot);
        ArrayAdapter spotadapter=new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,spot);
        spnSpot.setOnItemSelectedListener(this);

        spnPayment = findViewById(R.id.spnPayment);
        ArrayAdapter Paymentadapter=new ArrayAdapter((this,android.R.layout.simple_spinner_dropdown_item,Payment));
        spnPayment.setAdapter(paymentadapter);
        spnPayment.setOnClickListener(this);

        spnCarCompany = findViewById(R.id.spnCarCompany);
        CarCompanyAdapter companyAdapter = new CarCompanyAdapter((getApplicationContext()))
    }
    @Override
    public void onClick(View v)
    {
        if(v.getId() ==rdoOne.getId())
        {txtAmount.setText("$"+parkingRate);

    }
    else if(v.getId()==rdoTwo.getId())

        {
            txtAmount.setText("$" + parkingRate);
        }
        else if (v.getId() ==rdoThree.getId()) {
            txtAmount.setText("$" + parkingRate);
        }
        else if (v.getId() ==rdoFour.getId())
        {
            txtAmount.setText("$"+parkingRate);
        }

        }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if (adapterView.getId() == spnLot.getId())

            selectedLot = lots(position);
    }else if(adapterView).getId
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}