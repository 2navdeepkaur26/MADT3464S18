//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//var snackItems = [String]()
//var items = ["Tornado potato", "Shaved Ice", "Donuts", "Ice cream", "French Fries"]
var snacks : [String]
snacks = ["Tornado potato", "Shaved Ice", "Donuts", "Ice cream", "French Fries"]

print("Snacks : \(snacks)")

for snack in snacks{
    print("Each day : \(snack)")
}

for snack in 0..<snacks.count{
    print("New day : \(snacks[snack])")
}

for snack in snacks[2...]{
    print("New day One sided range: \(snack)")
}

for (index, value) in snacks.enumerated(){
    print("index : \(index) value : \(value)")
}

var numbers = Array(repeating: 1, count: 5)
print("numbers : \(numbers)")
numbers[2] = 25
print("numbers : \(numbers)")

var moreNumbers = Array(repeating: 0, count: 3)
moreNumbers[1] = 878
print("moreNumbers : \(moreNumbers)")

var allNumbers = numbers + moreNumbers
allNumbers[3] = numbers[1] + moreNumbers[2]
print("allNumbers : \(allNumbers)")

allNumbers[5] = 100
print("allNumbers : \(allNumbers)")

var grocery = ["Pringles", "Juice"]
grocery += ["fruits", "Chocolates"]
grocery.append("Tomatoes")
grocery.append("Rice")
print("Grocery : \(grocery)")

grocery[1...3] = ["Milk", "Veggies", "Mayo", "Chipotle", "Bread"]
print("Grocery : \(grocery)")

grocery.insert("Ice cream", at: 1)
grocery.remove(at: 7)
grocery.removeLast()
print("Grocery : \(grocery)")

grocery.removeAll()
if grocery.isEmpty{
    print("put everything in kitchen")
}else{
    print("go back to the market")
}

var rajnikanth = [Any]()
rajnikanth.append("Robot")
rajnikanth.append(2.0)
rajnikanth.append(1)
print("Rajnikanth : \(rajnikanth)")

//Set
var languages = Set<String>()
languages.insert("Gujarati")
languages.insert("Hindi")
languages.insert("English")
languages.insert("Punjabi")
languages.insert("Telugu")
languages.insert("Sanskrit")
print("languages : \(languages)")

languages.remove("Sanskrit")
print("Telugu is available in class : \(languages.contains("Telugu"))")
print("Sanskrit is available in class : \(languages.contains("Sanskrit"))")

for lang in languages.sorted(){
    print("language : \(lang)")
}

let motherTongue : Set = ["Gujarati", "Punjabi", "Urdu", "Hindi", "Telugu", "Marathi"]
print("MotherTongue : \(motherTongue)")

print("Union : \(languages.union(motherTongue).sorted())")
print("Intersection : \(languages.intersection(motherTongue).sorted())")
print("Symmetric difference : \(languages.symmetricDifference(motherTongue).sorted())")
print("Subtracting 1 - 2: \(languages.subtracting(motherTongue).sorted())")
print("Subtracting 2 - 1: \(motherTongue.subtracting(languages).sorted())")

var commonLangs = languages.intersection(motherTongue).sorted()
print("Common langs : \(commonLangs)")

print(languages.isSubset(of: commonLangs))
print(languages.isSuperset(of: commonLangs))
print(motherTongue.isDisjoint(with: languages))

//Dictionary
var appreciation = [String : String]()
appreciation["Day 1"] = "Potato Tornoado"
appreciation["Day 3"] = "Donuts"
print("appreciation : \(appreciation)")

print("\(appreciation.count) appreciation days")

//appreciation = [:]
if appreciation.isEmpty{
    print("No appreciation 😡...just studies")
}

appreciation["Day 2"] = "Shaved Ice"
print("appreciation : \(appreciation)")

let oldItem = appreciation.updateValue("Gola", forKey: "Day 2")
print("appreciation : \(appreciation)")
print("old Item : \(oldItem)")

if let day4Item = appreciation["Day 4"] {
    print("day4Item \(day4Item)")
}else{
    print("Nothing for day 4")
}

appreciation["Day 4"] = "Ice Cream"

if let removedValue = appreciation.removeValue(forKey: "Day 3") {
    print("\(removedValue) are not longer available")
    print("appreciation : \(appreciation)")
}else{
    print("Nothing found for Day 3")
}

appreciation["Day 2"] = nil
print("appreciation : \(appreciation)")

for app in appreciation.keys{
    print("app key : \(app)")
}

for app in appreciation.values{
    print("app values : \(app)")
}

for (key, value) in appreciation{
    print("key : \(key) value : \(value)")
}

var flight = [String : AnyObject]()
flight["number"] = "9W 234" as AnyObject
flight["duration"] = 16 as AnyObject
flight["cost"] = 1000.34 as AnyObject

print("flight : \(flight)")
